<?php

/**
 * Fired during plugin activation
 *
 * @link       http://easycomext.com/
 * @since      1.0.0
 *
 * @package    Wp_Vin_Q
 * @subpackage Wp_Vin_Q/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wp_Vin_Q
 * @subpackage Wp_Vin_Q/includes
 * @author     Carlos Trejo <carlos.trejo@gmail.com>
 */
class Wp_Vin_Q_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
